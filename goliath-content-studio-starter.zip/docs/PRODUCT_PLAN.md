# Product plan

## Goal
Content planning and publishing workflow.

## Scope
Editorial planning for LinkedIn, Instagram, Facebook, and TikTok, with source review, draft approval, and publishing integrations as future work.

## First milestone
- Choose a technology stack and document tradeoffs.
- Identify data sources, access limits, and privacy considerations.
- Build one working flow with clear tests.
- Write setup and deployment instructions.

## Not yet implemented
The current repository is a scaffold only.
