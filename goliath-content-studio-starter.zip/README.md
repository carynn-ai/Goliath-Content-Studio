# goliath-content-studio

Content planning and publishing workflow.

## Vision
Editorial planning for LinkedIn, Instagram, Facebook, and TikTok, with source review, draft approval, and publishing integrations as future work.

## Status
Initial repository scaffold; no application features implemented yet.

## Getting started with Codex
1. Create a **private** GitHub repository named `goliath-content-studio`.
2. Upload these files into the repo or push them using Git.
3. Authorize the repository in your Codex GitHub connection and create a Codex environment.
4. Ask Codex to draft an architecture proposal and implement a minimal first feature, with tests.

## Safety and security
Keep secrets in environment variables; do not commit credentials, personal data, or proprietary source code without authorization.
